package lesson4.lecture.finalinherit;

public class Super {
	static void print() {
		System.out.println("hello");
	}	
}
