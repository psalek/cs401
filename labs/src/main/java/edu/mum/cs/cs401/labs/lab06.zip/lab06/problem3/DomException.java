package edu.mum.cs.cs401.labs.lab06.problem3;

public class DomException extends Exception {

	public DomException() {
		super();
	}

	public DomException(String s) {
		super(s);
	}

}
